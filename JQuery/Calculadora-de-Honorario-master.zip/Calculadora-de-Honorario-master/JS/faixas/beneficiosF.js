//Benefícios Fiscais
const rioLog       = 2424;
const cartilhaModa = 1818;
const compete      = 2424;
const leiInd       = 2424;
const farmacos     = 1818;
const outrosF      = 1818;
const licitacaoSimples   = 606;
const licitacaoL   = 1818;
const industriaPR  = 1818;

export {
    rioLog,
    cartilhaModa,
    compete,
    leiInd,
    farmacos,
    outrosF,
    licitacaoSimples,
    licitacaoL,
    industriaPR
}

